aws cloudformation create-stack \
--stack-name UdagramApp \
--template-body file://udagram_networkandservers.yml \
--parameters file://udagram_networkandservers.json \
--region us-east-2 --capabilities CAPABILITY_NAMED_IAM